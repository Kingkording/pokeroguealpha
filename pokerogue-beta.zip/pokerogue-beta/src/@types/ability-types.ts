import type { AbAttrConstructorMap } from "#abilities/ab-attrs";
import type { applyAbAttrs } from "#abilities/apply-ab-attrs";
import type { Pokemon } from "#field/pokemon";
import type { Move } from "#moves/move";
import type { StatChange } from "./stat-change";

// intentionally re-export all types from ab-attrs to have this be the centralized place to import ability types
export type * from "#abilities/ab-attrs";

export type AbAttrCondition = (pokemon: Pokemon) => boolean;
export type PokemonAttackCondition = (user: Pokemon, target: Pokemon | null, move: Move) => boolean;
export type PokemonDefendCondition = (target: Pokemon, user: Pokemon, move: Move) => boolean;
export type PokemonStatStageChangeFunc = (target: Pokemon, changes: readonly StatChange[]) => StatChange;

/**
 * Union type of all ability attribute class names as strings
 */
export type AbAttrString = keyof AbAttrConstructorMap;

/**
 * Map of ability attribute class names to an instance of the class.
 */
export type AbAttrMap = {
  [K in keyof AbAttrConstructorMap]: InstanceType<AbAttrConstructorMap[K]>;
};

/**
 * Subset of ability attribute classes that may be passed to {@linkcode applyAbAttrs} method
 *
 * @remarks
 * Our AbAttr classes violate Liskov Substitution Principle.
 *
 * AbAttrs that are not in this have subclasses with apply methods requiring different parameters than
 * the base apply method.
 *
 * Such attributes may not be passed to the {@linkcode applyAbAttrs} method
 */
export type CallableAbAttrString =
  | Exclude<AbAttrString, "PreDefendAbAttr" | "PreAttackAbAttr">
  | "PreApplyBattlerTagAbAttr";

export type AbAttrParamMap = {
  [K in keyof AbAttrMap]: Parameters<AbAttrMap[K]["apply"]>[0];
};
