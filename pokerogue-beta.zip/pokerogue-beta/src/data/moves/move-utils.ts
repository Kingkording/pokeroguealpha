import { allMoves } from "#data/data-lists";
import { BattlerIndex } from "#enums/battler-index";
import { MoveCategory, type MoveDamageCategory } from "#enums/move-category";
import type { MoveId } from "#enums/move-id";
import { MoveTarget } from "#enums/move-target";
import { PokemonType } from "#enums/pokemon-type";
import type { WeatherType } from "#enums/weather-type";
import type { Pokemon } from "#field/pokemon";
import { applyMoveAttrs } from "#moves/apply-attrs";
import type { Move } from "#moves/move";
import type { MoveTargetSet } from "#types/move-target-set";
import { areAllies } from "#utils/pokemon-utils";
import { ValueHolder } from "#utils/value-holder";

/**
 * Return whether the move targets the field
 *
 * Examples include
 * - Hazard moves like spikes
 * - Weather moves like rain dance
 * - User side moves like reflect and safeguard
 */
export function isFieldTargeted(move: Move): boolean {
  switch (move.moveTarget) {
    case MoveTarget.BOTH_SIDES:
    case MoveTarget.USER_SIDE:
    case MoveTarget.ENEMY_SIDE:
      return true;
  }
  return false;
}

/**
 * Determine whether a move is a spread move.
 *
 * @param move - The {@linkcode Move} to check
 * @returns Whether {@linkcode move} is spread-targeted.
 * @remarks
 * Examples include:
 * - Moves targeting all adjacent Pokemon (like Surf)
 * - Moves targeting all adjacent enemies (like Air Cutter)
 */

export function isSpreadMove(move: Move): boolean {
  switch (move.moveTarget) {
    case MoveTarget.ALL_ENEMIES:
    case MoveTarget.ALL_NEAR_ENEMIES:
    case MoveTarget.ALL_OTHERS:
    case MoveTarget.ALL_NEAR_OTHERS:
      return true;
  }
  return false;
}

export function getMoveTargets(user: Pokemon, move: MoveId, replaceTarget?: MoveTarget): MoveTargetSet {
  const variableTarget = new ValueHolder(replaceTarget ?? allMoves[move].moveTarget);
  user.getOpponents(false).forEach(p => applyMoveAttrs("VariableTargetAttr", user, p, allMoves[move], variableTarget));

  const moveTarget: MoveTarget = variableTarget.value;
  const opponents = user.getOpponents(false);

  let set: Pokemon[] = [];
  let multiple = false;
  const ally: Pokemon | undefined = user.getAlly();
  switch (moveTarget) {
    case MoveTarget.USER:
    case MoveTarget.PARTY:
      set = [user];
      break;

    // biome-ignore lint/suspicious/noFallthroughSwitchClause: intentional
    case MoveTarget.CURSE:
      // Non ghost-type Curse targets exclusively the user; ghost-type Curse targets any enemy
      // TODO: check if the user is about to Terastallize to/from Ghost type
      if (!user.isOfType(PokemonType.GHOST, { returnOriginalTypesIfStellar: true })) {
        set = [user];
        break;
      }
    case MoveTarget.NEAR_OTHER:
    case MoveTarget.OTHER:
    case MoveTarget.ALL_NEAR_OTHERS:
    case MoveTarget.ALL_OTHERS:
      set = ally == null ? opponents : opponents.concat([ally]);
      multiple = moveTarget === MoveTarget.ALL_NEAR_OTHERS || moveTarget === MoveTarget.ALL_OTHERS;
      break;
    case MoveTarget.NEAR_ENEMY:
    case MoveTarget.ALL_NEAR_ENEMIES:
    case MoveTarget.ALL_ENEMIES:
    case MoveTarget.ENEMY_SIDE:
      set = opponents;
      multiple = moveTarget !== MoveTarget.NEAR_ENEMY;
      break;
    case MoveTarget.RANDOM_NEAR_ENEMY:
      set = [opponents[user.randBattleSeedInt(opponents.length)]];
      break;
    case MoveTarget.ATTACKER:
      // TODO: Remove MoveTarget.ATTACKER and BattlerIndex.ATTACKER
      return { targets: [BattlerIndex.ATTACKER], multiple: false };
    case MoveTarget.NEAR_ALLY:
    case MoveTarget.ALLY:
      set = ally == null ? [] : [ally];
      break;
    case MoveTarget.USER_OR_NEAR_ALLY:
    case MoveTarget.USER_AND_ALLIES:
    case MoveTarget.USER_SIDE:
      set = ally == null ? [user] : [user, ally];
      multiple = moveTarget !== MoveTarget.USER_OR_NEAR_ALLY;
      break;
    case MoveTarget.ALL:
    case MoveTarget.BOTH_SIDES:
      set = (ally == null ? [user] : [user, ally]).concat(opponents);
      multiple = true;
      break;
  }

  return {
    targets: set
      .filter(p => p?.isActive(true))
      .map(p => p.getBattlerIndex())
      .filter(t => t !== undefined),
    multiple,
  };
}

/**
 * Determine the target for the `user`'s counter-attack move
 * @param user - The pokemon using the counter-like move
 * @param damageCategory - The category of move to counter (physical or special), or `undefined` to counter both
 * @returns - The battler index of the most recent, non-ally attacker using a move that matches the specified category, or `null` if no such attacker exists
 */
export function getCounterAttackTarget(user: Pokemon, damageCategory?: MoveDamageCategory): BattlerIndex | null {
  for (const attackRecord of user.turnData.attacksReceived) {
    // check if the attacker was an ally
    const moveCategory = allMoves[attackRecord.move].category;
    const sourceBattlerIndex = attackRecord.sourceBattlerIndex;
    if (
      moveCategory !== MoveCategory.STATUS
      && !areAllies(sourceBattlerIndex, user.getBattlerIndex())
      && (damageCategory === undefined || moveCategory === damageCategory)
    ) {
      return sourceBattlerIndex;
    }
  }
  return null;
}

/**
 * Determine whether the move's {@linkcode Move#moveTarget | target} can target an opponent
 * @param move - The move to check
 * @returns Whether the move can target an opponent
 */
export function mayTargetOpponent(move: Move): boolean {
  switch (move.moveTarget) {
    case MoveTarget.NEAR_ENEMY:
    case MoveTarget.ALL_NEAR_ENEMIES:
    case MoveTarget.ALL_ENEMIES:
    case MoveTarget.ENEMY_SIDE:
    case MoveTarget.RANDOM_NEAR_ENEMY:
    case MoveTarget.ATTACKER:
      return true;
  }
  return false;
}

/**
 * @returns Whether the move is instantly charged by the given weather
 * @param move - The move to check
 * @param weather - The weather to check
 */
export function isWeatherInstantCharge(move: Move, weather: WeatherType): boolean {
  return !!move.findAttr(attr => attr.is("WeatherInstantChargeAttr") && attr.weatherTypes.includes(weather));
}
