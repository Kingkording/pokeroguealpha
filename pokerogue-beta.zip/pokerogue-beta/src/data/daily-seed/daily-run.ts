import { globalScene } from "#app/global-scene";
import { speciesDataRegistry } from "#app/global-species-data-registry";
import { dailyBiomeWeights } from "#balance/daily-biome-weights";
import { allChallenges } from "#data/challenge";
import type { PokemonSpecies } from "#data/pokemon-species";
import { BiomeId } from "#enums/biome-id";
import type { BiomePoolTier } from "#enums/biome-pool-tier";
import { Challenges } from "#enums/challenges";
import { EvoLevelThresholdKind } from "#enums/evo-level-threshold-kind";
import { MoveId } from "#enums/move-id";
import { MysteryEncounterType } from "#enums/mystery-encounter-type";
import { PartyMemberStrength } from "#enums/party-member-strength";
import type { SpeciesId } from "#enums/species-id";
import type { DailySeedBoss } from "#types/daily-run";
import type { Starter, StarterMoveset } from "#types/save-data";
import type { TupleRange } from "#types/type-helpers";
import { isBetween, randSeedGauss, randSeedInt, randSeedItem } from "#utils/common";
import { getEnumValues } from "#utils/enums";
import {
  getDailyRunStarter,
  isDailyEventSeed,
  validateDailyBossConfig,
  validateDailyStarterConfig,
} from "./daily-seed-utils";

type StarterTuple = TupleRange<1, 6, Starter>;

/**
 * Generate the daily run starters.
 * @returns A tuple of 3 {@linkcode Starter}s
 */
export function getDailyRunStarters(): StarterTuple {
  const starters: Starter[] = [];
  const seed = globalScene.seed;
  globalScene.executeWithSeedOffset(
    () => {
      const eventStarters = getDailyEventSeedStarters();
      if (eventStarters != null) {
        starters.push(...eventStarters);
        return;
      }

      // TODO: explain this math
      const startingLevel = globalScene.gameMode.getStartingLevel();
      const starterCosts: number[] = [];
      starterCosts.push(Math.min(Math.round(3.5 + Math.abs(randSeedGauss(1))), 8));
      starterCosts.push(randSeedInt(9 - starterCosts[0], 1));
      starterCosts.push(10 - (starterCosts[0] + starterCosts[1]));

      for (const cost of starterCosts) {
        const costSpecies = speciesDataRegistry.getStartersForCost(cost).filter(
          s =>
            // make sure there are no duplicate starters from the same line
            !starters.some(st => s === st.speciesId || speciesDataRegistry.getStarter(s) === st.speciesId),
        );
        const randPkmSpecies = speciesDataRegistry.getSpecies(randSeedItem(costSpecies));
        const starterSpecies = speciesDataRegistry.getSpecies(
          randPkmSpecies.getTrainerSpeciesForLevel(
            startingLevel,
            true,
            PartyMemberStrength.STRONGER,
            EvoLevelThresholdKind.STRONG,
          ),
        );
        starters.push(getDailyRunStarter(starterSpecies));
      }
    },
    0,
    seed,
  );

  setDailyRunEventStarterMovesets(starters as StarterTuple);

  return starters as StarterTuple;
}

/**
 * Get daily run starting biome.
 * @returns The {@linkcode BiomeId}
 */
export function getDailyStartingBiome(): BiomeId {
  const eventBiome = getDailyEventSeedBiome();
  if (eventBiome != null) {
    return eventBiome;
  }

  // TODO: use weighted RNG utility function `weightedPick` from `src/utils/random.ts`
  const biomes = Object.values(BiomeId);
  let totalWeight = 0;
  const biomeThresholds: number[] = [];
  for (const biome of biomes) {
    const weight = dailyBiomeWeights[biome];

    // Keep track of the total weight & each biome's cumulative weight
    totalWeight += weight;
    biomeThresholds.push(totalWeight);
  }

  const randInt = randSeedInt(totalWeight);

  for (let i = 0; i < biomes.length; i++) {
    if (randInt < biomeThresholds[i]) {
      return biomes[i];
    }
  }

  return randSeedItem(biomes);
}

/**
 * Perform moveset post-processing on Daily run starters.
 * @remarks
 * If the {@linkcode CustomDailyRunConfig} has the `starters` property with a `moveset` property,
 * the movesets will be overwritten.
 * @param starters - The previously generated starters; will have movesets mutated in place
 */
function setDailyRunEventStarterMovesets(starters: StarterTuple): void {
  const movesets = globalScene.gameMode.dailyConfig?.starters?.map(s => s.moveset);
  if (movesets == null) {
    return;
  }

  const moveIds = getEnumValues(MoveId);
  for (const [index, moveset] of movesets.entries()) {
    if (moveset == null) {
      continue;
    }

    if (moveset.some(f => !moveIds.includes(f))) {
      console.error(
        `Custom daily run starter #${index}'s moveset had one or more invalid Move IDs!`
          + `\nStarter moveset: ${moveset}`,
      );
      return;
    }

    if (!isBetween(moveset.length, 0, 4)) {
      console.error(
        `Custom daily run starter #${index}'s moveset had incorrect length (${moveset.length})!`
          + `\nStarter Moveset: ${moveset.map(m => MoveId[m]).join(", ")}`,
      );
      return;
    }

    const starter = starters[index];
    starter.moveset = moveset as StarterMoveset;
  }
}

/**
 * Parse a custom daily run seed into a set of pre-defined starters.
 * @see {@linkcode CustomDailyRunConfig}
 * @returns An array of {@linkcode Starter}s, or `null` if the config is invalid.
 */
function getDailyEventSeedStarters(): StarterTuple | null {
  if (!isDailyEventSeed()) {
    return null;
  }

  const speciesConfigurations = globalScene.gameMode.dailyConfig?.starters;

  if (speciesConfigurations == null) {
    return null;
  }

  const starters: Starter[] = [];

  for (const speciesConfig of speciesConfigurations) {
    const starterConfig = validateDailyStarterConfig(speciesConfig);
    if (!starterConfig) {
      return null;
    }

    const species = speciesDataRegistry.getSpecies(starterConfig.speciesId);

    const starter = getDailyRunStarter(species, starterConfig);

    starters.push(starter);
  }

  return starters as StarterTuple;
}

/**
 * Sets a custom boss for the daily run if specified in the config.
 * @returns The {@linkcode DailySeedBoss} to use, or `null` if there is no boss config or the {@linkcode SpeciesId} is invalid.
 * @see {@linkcode CustomDailyRunConfig}
 */
export function getDailyEventSeedBoss(): DailySeedBoss | null {
  if (!isDailyEventSeed()) {
    return null;
  }

  const { dailyConfig } = globalScene.gameMode;
  if (!dailyConfig?.boss) {
    return null;
  }

  const bossConfig = validateDailyBossConfig(dailyConfig.boss);
  return bossConfig;
}

/**
 * Get the species for a forced wave for custom daily run.
 * @param waveIndex - The wave index to check
 * @returns The {@linkcode PokemonSpecies} to use, or `null` if there is no forced wave for the given index.
 */
export function getDailyForcedWaveSpecies(waveIndex: number): PokemonSpecies | null {
  if (!isDailyEventSeed()) {
    return null;
  }

  // Only override the first enemy if it's a double battle
  if (globalScene.getEnemyParty().length > 0) {
    return null;
  }

  const forcedWave = globalScene.gameMode.dailyConfig?.forcedWaves?.find(w => w.waveIndex === waveIndex);
  if (forcedWave?.speciesId == null) {
    return null;
  }

  return speciesDataRegistry.getSpecies(forcedWave.speciesId);
}

/**
 * Get the biome pool tier for a forced wave for custom daily run.
 * @param waveIndex - The wave index to check
 * @returns The {@linkcode BiomePoolTier} to use, or `null` if there is no forced wave for the given index.
 */
export function getDailyForcedWaveBiomePoolTier(waveIndex: number): BiomePoolTier | null {
  if (!isDailyEventSeed()) {
    return null;
  }

  // Only override the first enemy if it's a double battle
  if (globalScene.getEnemyParty().length > 0) {
    return null;
  }

  const forcedWave = globalScene.gameMode.dailyConfig?.forcedWaves?.find(w => w.waveIndex === waveIndex);
  if (forcedWave?.tier == null) {
    return null;
  }

  return forcedWave.tier;
}

/**
 * Check if the current wave should have the hidden ability in a custom daily run.
 * @param waveIndex - The wave index to check
 * @returns Whether the wave should have the hidden ability.
 */
export function isDailyForcedWaveHiddenAbility(): boolean {
  if (!isDailyEventSeed()) {
    return false;
  }

  // Only override the first enemy if it's a double battle
  if (globalScene.getEnemyParty().length > 0) {
    return false;
  }

  const forcedWave = globalScene.gameMode.dailyConfig?.forcedWaves?.find(
    w => w.waveIndex === globalScene.currentBattle.waveIndex,
  );
  if (forcedWave == null) {
    return false;
  }

  return forcedWave.hiddenAbility ?? false;
}

/**
 * Check if the current wave should be a trainer battle in a custom daily run.
 * @param waveIndex - The wave index to check
 * @returns The {@linkcode DailyTrainerManipulation} to use, or `null` if there is no forced wave for the given index.
 */
export function getDailyTrainerManipulation(waveIndex: number): boolean | null {
  if (!isDailyEventSeed()) {
    return null;
  }
  const trainerManipulation = globalScene.gameMode.dailyConfig?.trainerManipulations?.find(
    w => w.waveIndex === waveIndex,
  );
  if (trainerManipulation == null) {
    return null;
  }

  return trainerManipulation.isTrainer;
}

/**
 * Starts the challenges for a custom daily run.
 */
export function startDailyEventChallenges(): void {
  if (!isDailyEventSeed()) {
    return;
  }

  const { dailyConfig } = globalScene.gameMode;

  for (const dailyChallenge of dailyConfig?.challenges ?? []) {
    if (!getEnumValues(Challenges).includes(dailyChallenge.id)) {
      console.warn("Invalid challenge ID used for custom daily run seed:", dailyChallenge.id);
      continue;
    }
    // check that the value is a valid number for the challenge type
    const challenge = allChallenges.find(c => c.id === dailyChallenge.id);
    if (!challenge) {
      console.warn("Invalid challenge ID used for custom daily run seed:", dailyChallenge.id);
      continue;
    }
    if (!isBetween(dailyChallenge.value, 1, challenge.maxValue)) {
      console.warn("Invalid challenge value used for custom daily run seed:", dailyChallenge.value);
      continue;
    }
    globalScene.gameMode.setChallengeValue(dailyChallenge.id, dailyChallenge.value);
  }
}

/**
 * Get the {@linkcode MysteryEncounterType} for a custom daily run.
 * @param waveIndex - The wave index to check
 * @returns The {@linkcode MysteryEncounterType} to use, or `null` if there is no forced wave for the given index.
 */
export function getDailyMysteryEncounter(waveIndex: number): MysteryEncounterType | null {
  if (!isDailyEventSeed()) {
    return null;
  }

  const mysteryEncounter = globalScene.gameMode.dailyConfig?.mysteryEncounters?.find(w => w.waveIndex === waveIndex);
  if (mysteryEncounter == null) {
    return null;
  }

  if (!getEnumValues(MysteryEncounterType).includes(mysteryEncounter.type)) {
    console.warn("Invalid mystery encounter type used for custom daily run seed:", mysteryEncounter.type);
    return null;
  }

  return mysteryEncounter.type;
}

/**
 * Sets a custom starting biome for the daily run if specified in the config.
 * @see {@linkcode CustomDailyRunConfig}
 * @returns The biome to use or `null` if no valid match.
 */
export function getDailyEventSeedBiome(): BiomeId | null {
  if (!isDailyEventSeed()) {
    return null;
  }

  const startingBiome = globalScene.gameMode.dailyConfig?.biome;

  if (startingBiome == null) {
    return null;
  }

  if (!Object.values(BiomeId).includes(startingBiome)) {
    console.warn("Invalid biome ID used for custom daily run seed:", startingBiome);
    return null;
  }

  return startingBiome;
}

/**
 * Sets a custom luck value for the daily run if specified in the config.
 * @see {@linkcode CustomDailyRunConfig}
 * @returns The custom luck value or `null` if there is no luck property.
 */
export function getDailyEventSeedLuck(): number | null {
  if (!isDailyEventSeed()) {
    return null;
  }

  const luck = globalScene.gameMode.dailyConfig?.luck;

  if (luck == null) {
    return null;
  }

  if (luck < 0 || luck > 14) {
    console.warn("Invalid luck value used for custom daily run seed:", luck);
    return null;
  }

  return luck;
}

/**
 * Sets a custom starting money value for the daily run if specified in the config.
 * @see {@linkcode CustomDailyRunConfig}
 * @returns The custom money value, or `undefined` if there is no money property.
 */
export function getDailyStartingMoney(): number | undefined {
  if (!isDailyEventSeed()) {
    return;
  }

  const { startingMoney } = globalScene.gameMode.dailyConfig ?? {};
  if (startingMoney == null) {
    return;
  }

  if (startingMoney < 0 || !Number.isSafeInteger(startingMoney)) {
    console.warn("Invalid starting money value used for custom daily run seed!\nMoney: ", startingMoney);
    return;
  }

  return startingMoney;
}
